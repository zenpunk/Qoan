$wnd.qube_qoan_MyWidgetset.runAsyncCallback2('Cpb(2134,1,taf);_.Ac=function VCc(){ldc((!ddc&&(ddc=new tdc),ddc),this.a.d)};y4e(Qh)(2);\n//# sourceURL=qube.qoan.MyWidgetset-2.js\n')
